package server;

import java.awt.Point;

/**
 * The Item class details the location of the item on screen
 * 
 * @author Carson Boyd
 * 
 */
public class Item {

	private Point location;

	public Item(int x, int y) {

		setLocation(new Point(x, y));

	}

	public Point getLocation() {
		return location;
	}

	public void setLocation(Point location) {
		this.location = location;
	}

}
