README - Snake Game
-------------------

Students:

Carson Boyd      - s3284153
Mitchell Stewart - s3282453

Carson's Contribution
---------------------

Carson was in charge of the server functionality at the start of the project.
But later on it was agreed that both students help to finish off the server functionality.

Carson completed most of the Server functionality, including the movement and the collision functions.

Mitchell's Contribution
---------------------

Mitchell was in charge of the Client functionality, including finding a way to get a message from the server to the client and for the client to send a message to the server. He came up with the idea to use a string parsing system as a messaging system, which has worked well in being able to adapt to the different objects that need to be represented in the game.



List of Incomplete Functionality
--------------------------------

Increase Speed
Decrease Speed
Obtaining Items in order to grow.
Final Winner scores / declarations.

Picking of number of players / corners of First/All Players

Known Bugs
----------
Some collisions may not work since proper testing has not been done yet.

N/A.